package Login_Feature;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class Register_Modules extends JFrame {
	
	JPanel pnl = new JPanel();
	
	JLabel year= new JLabel("Year of Programme: ");
	JLabel m_one = new JLabel("Module 1: ");
	JLabel m_two = new JLabel("Module 2: ");
	JLabel m_three = new JLabel("Module 3: ");
	JLabel m_four = new JLabel("Module 4: ");
	JLabel m_five = new JLabel("Module 5: ");
	JLabel m_six = new JLabel("Module 6: ");
	
	
	
	private Register_Modules rm;
	private Student student;
	
	
	public Register_Modules(Student student){
		
		super("Register Modules");
	    setLayout(new FlowLayout());
	    
	    pnl.setLayout(new GridBagLayout());
	    add(pnl);
	    
	    GridBagConstraints gc= new GridBagConstraints();
	    
	    gc.insets = new Insets(6, 6, 6, 6);
		gc.anchor = GridBagConstraints.EAST;
		gc.weightx = 0.5;
		gc.weighty = 0.5;

		gc.gridx = 0;
		gc.gridy = 0;

		pnl.add(year, gc);

		gc.gridx = 0;
		gc.gridy = 1;
		pnl.add(m_one, gc);

		gc.gridx = 0;
		gc.gridy = 2;
		pnl.add(m_two, gc);

		gc.gridx = 0;
		gc.gridy = 3;
		pnl.add(m_three, gc);

		gc.gridx = 0;
		gc.gridy = 5;
		pnl.add(m_four, gc);
		
		gc.gridx = 0;
		gc.gridy = 6;
		pnl.add(m_five, gc);
		
		gc.gridx = 0;
		gc.gridy = 7;
		pnl.add(m_six, gc);
		
		
	}

}
