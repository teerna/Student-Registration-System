package Login_Feature;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Student extends JFrame {
	
	JPanel panel= new JPanel();
	JPanel panel1= new JPanel();
	JLabel fnameTitle= new JLabel("First Name: ");
	JLabel fnameL= new JLabel();
	JLabel lnameTitle= new JLabel("Last Name: ");
	JLabel lnameL= new JLabel();
	JLabel hcontactTitle= new JLabel("Landline Contact: ");
	JLabel hcontactL= new JLabel();
	JLabel mcontactTitle= new JLabel("Mobile Contact: ");
	JLabel mcontactL= new JLabel();
	JLabel dobTitle= new JLabel("Date of Birth: ");
	JLabel dobL= new JLabel();
	JLabel courseTitle= new JLabel("Programme Course: ");
	JLabel courseL= new JLabel();
	JLabel yearTitle= new JLabel("Year of Programme: ");
	JLabel yearL= new JLabel();
	JButton registerBtn= new JButton("Register Modules");
	
	private Student stdt;
	private login log2;
	
	
	public Student(login log2){
		
		super("Account");
		
		stdt=this;
		this.log2=log2;
		
		setLayout(new FlowLayout());
		
		Border border = new CompoundBorder(
				new TitledBorder(null, "Account Details", TitledBorder.CENTER,
						TitledBorder.TOP, null),
				new EmptyBorder(10, 10, 10, 10));
		
		panel.setBorder(border);
		
		panel.setLayout(new GridBagLayout());
		panel1.setLayout(new GridBagLayout());
		add(panel);
		add(panel1);
		
		GridBagConstraints gbc= new GridBagConstraints();
		
		gbc.insets= new Insets(6,6,6,6);
		
		gbc.gridx=0;
		gbc.gridy=0;
	    panel.add(fnameTitle, gbc);
	    
	    gbc.gridx=0;
		gbc.gridy=1;
	    panel.add(lnameTitle, gbc);
	    
	    gbc.gridx=0;
		gbc.gridy=2;
	    panel.add(hcontactTitle, gbc);
	    
	    gbc.gridx=0;
		gbc.gridy=3;
	    panel.add(mcontactTitle, gbc);
	    
	    gbc.gridx=0;
		gbc.gridy=4;
	    panel.add(dobTitle, gbc);
	    
	    gbc.gridx=0;
		gbc.gridy=5;
	    panel.add(courseTitle, gbc);
	    
	    gbc.gridx=0;
		gbc.gridy=6;
	    panel.add(yearTitle, gbc);
		
		String fname;
		try{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con= null;
			
			con= DriverManager.getConnection("jdbc:mysql://localhost:3306/accounts?autoReconnect=true&useSSL=false", "root","admin");
			
			Statement st= con.createStatement();
			
			String user1= log2.user;
			
			ResultSet rs= st.executeQuery("Select fname, lname, home_contact, mob_contact,dob,course,current_year from student_details inner join student on student_details.student_id= student.student_ID where username= '"+user1+"'");			
				
			while(rs.next()){		
				
				gbc.gridx=1;
				gbc.gridy=0;
				
				fname= rs.getString("fname");
				fnameL.setText(fname);
				panel.add(fnameL, gbc);
				
				//////////////////////////////
				
				gbc.gridx=1;
				gbc.gridy=1;
				
				String lname= rs.getString("lname");
				lnameL.setText(lname);
				panel.add(lnameL, gbc);
				
				/////////////////////////////
								
				gbc.gridx=1;
				gbc.gridy=2;
				
				int home_contact=rs.getInt("home_contact");
				
				String h_contact= Integer.toString(home_contact);
				hcontactL.setText(h_contact);
				panel.add(hcontactL, gbc);
				
				//////////////////////////////
				
				gbc.gridx=1;
				gbc.gridy=3;
				int mob_contact= rs.getInt("mob_contact");
				String m_contact= Integer.toString(mob_contact);
				mcontactL.setText(m_contact);
				panel.add(mcontactL, gbc);
				
				////////////////////////////////
				
				gbc.gridx=1;
				gbc.gridy=4;
				String dob= rs.getString("dob");
				
				dobL.setText(dob);
				panel.add(dobL, gbc);
				
				////////////////////////////////
				
				gbc.gridx=1;
				gbc.gridy=5;
				String course= rs.getString("course");
				
				courseL.setText(course);
				panel.add(courseL, gbc);
				
				///////////////////////////////
				
				gbc.gridx=1;
				gbc.gridy=6;
				String year= rs.getString("current_year");
				
				yearL.setText(year);
				panel.add(yearL, gbc);
				
				
			}
			
		}
		
		catch(Exception e){
			e.printStackTrace();
		}
		
		gbc.insets= new Insets(6,6,6,6);
		
		gbc.gridx=0;
		gbc.gridy=0;
		panel1.add(registerBtn, gbc);
		
		
		RegisterModules regHandler= new RegisterModules();
		registerBtn.addActionListener(regHandler);
		
		
	}
	
	public class RegisterModules implements ActionListener{
		public void actionPerformed(ActionEvent e){
			
			stdt.setVisible(true);
			Register_Modules rm= new Register_Modules(stdt);
			rm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			rm.setSize(600, 450);
			rm.setLocationRelativeTo(null);
		    rm.setVisible(true);	
			
		}
	}
	
}
