package Login_Feature;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.imageio.ImageIO;
import javax.swing.*;

public class login extends JFrame {
		
		JButton loginBtn = new JButton("Login");
		JTextField userntf= new JTextField(15);
		JTextField passtf= new JTextField(15);
		JLabel userl= new JLabel("Username:");
		JLabel passl= new JLabel("Password:");
		JLabel bgpic= new JLabel();
		JPanel panel= new JPanel();
		private BufferedImage image;
		public String user;
		public String pass;
		private login log1; 
		
		

	public login(){
		
		this.setTitle("Module Registration System");
		log1=this;
		setLayout(new GridBagLayout());
		GridBagConstraints gbc= new GridBagConstraints();
	
		
		//getContentPane().add(panel,gbc);
		//bgpic.setIcon(new ImageIcon("C:/Users/Diksha/workspace/OOSD Assignment/src/Login_Feature/1681597856-1-f.jpg"));

		panel.setLayout(new GridBagLayout());

		 /*try {
				image = ImageIO.read(new File("C:/Users/Diksha/workspace/GUI Assignment/src/OOSD Assignment/icons/rrrr.jpg"));
				
				this.setContentPane(new JLabel(new ImageIcon(image)));
			} catch (IOException e) {
				e.printStackTrace();
			}*/
		
		
		gbc.insets = new Insets(6, 6, 6, 6);
		gbc.anchor = GridBagConstraints.CENTER;
		gbc.weightx = 0.5;
		gbc.weighty = 0.5;

		gbc.gridx = 0;
		gbc.gridy = 0;
		
		panel.add(userl,gbc);
		
		gbc.gridx=0;
		gbc.gridy=1;
		
		panel.add(passl, gbc);
		
		gbc.gridx=1;
		gbc.gridy=0;
		
		panel.add(userntf, gbc);
		
		gbc.gridx=1;
		gbc.gridy=1;
		
		panel.add(passtf,gbc);
		
		gbc.gridx=1;
		gbc.gridy=2;
		panel.add(loginBtn,gbc);
		
		add(panel,gbc);
		
		Login loginHandler= new Login();
		loginBtn.addActionListener(loginHandler);
		
		
	}
	
	public class Login implements ActionListener{
		public void actionPerformed(ActionEvent evt){
			
			
			
			try {
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				
				Connection con= null;
				
				con= DriverManager.getConnection("jdbc:mysql://localhost:3306/accounts?autoReconnect=true&useSSL=false", "root", "admin");
			
			    Statement st= con.createStatement();
				
				ResultSet rs= st.executeQuery("Select * from student, administrator");
				
				 user= userntf.getText();
				 pass= passtf.getText();
				
				while(rs.next()){
					
					if(user.equals(rs.getString("username"))&&pass.equals(rs.getString("password")) ){
						//JOptionPane.showMessageDialog(login.this, String.format("Login Successful"));
						//break;
						log1.setVisible(true);
						Student std= new Student(log1);
						std.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						std.setSize(600, 450);
						std.setLocationRelativeTo(null);
					    std.setVisible(true);	
									
						
					}
					
					if(user.equals(rs.getString("admin_username"))&& pass.equals(rs.getString("admin_password"))){
						JOptionPane.showMessageDialog(login.this, String.format("Admin Login"));
						break;
					}
									
				}	
				
				
				
				con.close();
								
			}
						
			catch(Exception e) {
	            System.err.println("Got an exception!");
	            System.err.println(e.getMessage());}
			
		
	   }

	}
}
