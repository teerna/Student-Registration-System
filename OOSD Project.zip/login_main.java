package Login_Feature;

import javax.swing.JFrame;

public class login_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	    login log = new login();
		
		log.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		log.setSize(600, 450);
		log.setLocationRelativeTo(null);
	    log.setVisible(true);

	}

}
