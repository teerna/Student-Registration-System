package Login_Feature;

public class User {
	
	private int studentid;
    private String fname,lname,course,current_year;
    
   public User(int studentid, String fname, String lname, String course, String current_year)
   {
	   this.studentid=studentid;
	   this.fname=fname;
	   this.lname=lname;
	   this.course=course;
	   this.current_year=current_year;
	   
   }
   
   public int getstudentid(){
	   
	   return studentid;
   }
   
   public String getfname(){
	   
	   return fname;
	   
   }
   
   public String getlname(){
	   
	   return lname;
	   
   }

   public String getcourse(){
	   
	   return course;
	   
   }

   public String getcurrent_year(){
	   
	   return current_year;
	   
   }

}
