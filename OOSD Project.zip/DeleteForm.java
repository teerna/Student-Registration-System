package Login_Feature;


import java.sql.*;

import net.proteanit.sql.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.util.*;

public class DeleteForm extends javax.swing.JFrame {
	
	Connection myConn = null;
	PreparedStatement myStmt = null;
	ResultSet myRs = null;
	
	Statement mySt =null;
    
    public DeleteForm() {
    	
    	 try {
         	
        	 // 1. Get a connection to database
			myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/accounts?autoReconnect=true&useSSL=false", "root" , "admin");
			
		
						}
    	 
    	  catch (Exception exc) {
  			exc.printStackTrace();
          }
    	
        initComponents();
        
            
    }

    
    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jLabelDeleteForm = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jCheckBoxEditable = new javax.swing.JCheckBox();
        jCheckBoxUneditable = new javax.swing.JCheckBox();
        jButtonRefresh = new javax.swing.JButton();
        jButtonDelete = new javax.swing.JButton();
        jButtonUpdate = new javax.swing.JButton();
        jButtonBack = new javax.swing.JButton();
        jLabelBackground = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(900, 600));
        setPreferredSize(new java.awt.Dimension(900, 600));
        getContentPane().setLayout(null);

        jLabelDeleteForm.setFont(new java.awt.Font("Arial", 1, 25)); 
        jLabelDeleteForm.setText("Update and Delete Form");
        getContentPane().add(jLabelDeleteForm);
        jLabelDeleteForm.setBounds(310, 20, 300, 70);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                
            },

            
            new String [] {
              "Student id" , "First Name", "Last Name", "Programme Course", "Year of Programme"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(170, 120, 540, 270);

        jCheckBoxEditable.setFont(new java.awt.Font("Arial", 1, 18)); 
        jCheckBoxEditable.setText("Editable");
        jCheckBoxEditable.setContentAreaFilled(false);
        jCheckBoxEditable.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCheckBoxEditableItemStateChanged(evt);
            }
        });
        getContentPane().add(jCheckBoxEditable);
        jCheckBoxEditable.setBounds(240, 420, 120, 31);

        jCheckBoxUneditable.setFont(new java.awt.Font("Arial", 1, 18)); 
        jCheckBoxUneditable.setSelected(true);
        jCheckBoxUneditable.setText("Uneditable");
        jCheckBoxUneditable.setContentAreaFilled(false);
        jCheckBoxUneditable.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCheckBoxUneditableItemStateChanged(evt);
            }
        });
        getContentPane().add(jCheckBoxUneditable);
        jCheckBoxUneditable.setBounds(480, 420, 120, 31);

        jButtonRefresh.setText("Refresh Table");
        jButtonRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRefreshActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonRefresh);
        jButtonRefresh.setBounds(175, 490, 120, 30);
        
        jButtonDelete.setText("Delete Row");
        jButtonDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDeleteActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonDelete);
        jButtonDelete.setBounds(310, 490, 120, 30);
        
        
        jButtonUpdate.setText("Update Row");
        jButtonUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonUpdateActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonUpdate);
        jButtonUpdate.setBounds(460, 490, 120, 30);
        
        
        jButtonBack.setText("Back");
        jButtonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBackActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonBack);
        jButtonBack.setBounds(600, 490, 70, 30);

        jLabelBackground.setIcon(new javax.swing.ImageIcon("C:\\Users\\issen\\Desktop\\del.jpg")); // NOI18N
        jLabelBackground.setMinimumSize(new java.awt.Dimension(900, 600));
        jLabelBackground.setPreferredSize(new java.awt.Dimension(900, 600));
        getContentPane().add(jLabelBackground);
        jLabelBackground.setBounds(0, 0, 900, 600);

        pack();
    }                       

    private void jCheckBoxEditableItemStateChanged(java.awt.event.ItemEvent evt) {                                                   
        
    }                                                  

    private void jCheckBoxUneditableItemStateChanged(java.awt.event.ItemEvent evt) {                                                     
        
    }                                                    

    private void jButtonRefreshActionPerformed(java.awt.event.ActionEvent evt) {   
    	
try{
    		
    		String q="select student_id, fname,lname,course,current_year from student_details";
    		myStmt=myConn.prepareStatement(q);
    		myRs=myStmt.executeQuery();
    		
    		jTable1.setModel(DbUtils.resultSetToTableModel(myRs));
    	}
    	catch(Exception e){
    		
    		JOptionPane.showMessageDialog(null, e);
    	}
    	
        
    } 
    
    
    
    public ArrayList<User> userList(){
    	
    	ArrayList<User> usersList = new ArrayList<>();
    	
    	try{
    		
    		String query="select student_id, fname,lname,course,current_year from student_details";
    	    mySt=myConn.createStatement();
    		myRs=mySt.executeQuery(query);
    		
    		User user;
    		
    		while(myRs.next()){
    			 
    			user= new User (myRs.getInt("student_id"),myRs.getString("fname"), myRs.getString("lname"), myRs.getString("course"), myRs.getString("current_year") );
    			usersList.add(user);
    			
    		}
    		
    		
    	}
    	
    	catch(Exception e){
    		
    		JOptionPane.showMessageDialog(null, e);
    		
    		
    	}
    	
    	return usersList;
    	
    	}
    	
    
    
    
    
    public void show_user(){
    	
    	ArrayList<User> list = userList();
    	
    	DefaultTableModel model= (DefaultTableModel)jTable1.getModel();
    	
    	Object [] row = new Object[5];
    	for(int i=0;i<list.size();i++){
    		
    		row[0]=list.get(i).getstudentid();
    		row[1]=list.get(i).getfname();
    		row[2]=list.get(i).getlname();
    		row[3]=list.get(i).getcourse();
    		row[4]=list.get(i).getcurrent_year();
    		model.addRow(row);
    	}
    }
    
    
    private void jButtonDeleteActionPerformed(java.awt.event.ActionEvent evt) {                                            
      try{  
    	int row=jTable1.getSelectedRow();
		String value=(jTable1.getModel().getValueAt(row, 0).toString());
		String q="DELETE FROM Student_details where student_id="+value;
		PreparedStatement myStmt= myConn.prepareStatement(q);
    	myStmt.executeUpdate();
    	DefaultTableModel model= (DefaultTableModel)jTable1.getModel();
		model.setRowCount(0);
		show_user();
    } 
      catch(Exception e){
    	  
    	  JOptionPane.showMessageDialog(null, e);
      }
    }
    private void jButtonUpdateActionPerformed(java.awt.event.ActionEvent evt) {          
    	
	try{
    	
			int row=jTable1.getSelectedRow();
			String value=(jTable1.getModel().getValueAt(row, 0).toString());
		    String fname=(jTable1.getModel().getValueAt(row, 1).toString());
		    String lname=(jTable1.getModel().getValueAt(row, 2).toString());
		    String course=(jTable1.getModel().getValueAt(row, 3).toString());
		    String currentyear=(jTable1.getModel().getValueAt(row, 4).toString());
    		String q="Update Student_details SET fname=?, lname=?, course=?, current_year=? where student_id="+value;
    		PreparedStatement myStmt= myConn.prepareStatement(q);
    		myStmt.setString(1,fname);
    		myStmt.setString(2,lname);
    		myStmt.setString(3,course);
    		myStmt.setString(4,currentyear);
    		myStmt.executeUpdate();
    		DefaultTableModel model= (DefaultTableModel)jTable1.getModel();
    		model.setRowCount(0);
    		show_user();
    	}
    	catch(Exception e){
    		
    		JOptionPane.showMessageDialog(null, e);
    	}
        
    }                                           

    private void jButtonBackActionPerformed(java.awt.event.ActionEvent evt) {                                            
      
    }                                           

    public static void main(String args[]) throws SQLException {
    	
    
      
        
       try{
			
			// Delete statement
			
			//String sql= "delete from student_details where lname='Brown'";
			
			
			
			//int rowAffected=myStmt.executeUpdate(sql);
			
			//System.out.println("Row affected: " +rowAffected );
			
			//System.out.println("Deletion completed");
			
		
			
        	
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DeleteForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DeleteForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DeleteForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DeleteForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
      
     
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DeleteForm().setVisible(true);
            }
        });
    }


	private javax.swing.JButton jButtonBack;
    private javax.swing.JButton jButtonRefresh;
    private javax.swing.JButton jButtonDelete;
    private javax.swing.JButton jButtonUpdate;
    private javax.swing.JCheckBox jCheckBoxEditable;
    private javax.swing.JCheckBox jCheckBoxUneditable;
    private javax.swing.JLabel jLabelBackground;
    private javax.swing.JLabel jLabelDeleteForm;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
                   
}

